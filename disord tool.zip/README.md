# EzNuke
## _Open Source Dicord Account Nuker_

This nuker abuses the discord api to mess with user accounts.

## Installation

- Install Python From [Here](https://python.org)
- Run The Following Commands To Install Required Modules
    - pip3 install colorama
    - pip3 install requests

## Usage
- Run The Following Command To Start The Nuker
    - python3 Nuker.py
    - Follow Instructions In The Program

## Preview
![Image](https://cdn.discordapp.com/attachments/840273256464252959/844025805020463174/unknown.png)

## Todo
- Add An Option To Multiprocess Or Multithread Every Module
- Improve Code Formatting
- Improve Speed

